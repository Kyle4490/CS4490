pip install ./raymarching
pip install ./shencoder
pip install ./freqencoder
pip install ./gridencoder